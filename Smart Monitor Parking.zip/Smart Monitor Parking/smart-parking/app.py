from flask import Flask, render_template, jsonify, request
from config import FLASK_PORT, DEBUG_MODE
from tb_client import ThingsBoardClient

app = Flask(__name__)
tb_client = ThingsBoardClient()

def parse_telemetry(telemetry_data):
    """Parses ThingsBoard telemetry format into a simpler dict."""
    result = {}
    if not telemetry_data:
        return result
        
    for key, values in telemetry_data.items():
        if values and len(values) > 0:
            # Get the most recent value
            result[key] = values[0]['value']
    return result

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/status')
def get_status():
    # Fetch telemetry from ThingsBoard
    # We expect keys: slot1_occupied, slot2_occupied (and optionally distance)
    telemetry = tb_client.get_latest_telemetry()
    parsed_telemetry = parse_telemetry(telemetry)
    
    # Construct state for frontend
    state = {
        'slot1': {
            'occupied': parsed_telemetry.get('slot1_occupied') == 'true' or parsed_telemetry.get('slot1_occupied') == True,
            'distance': parsed_telemetry.get('slot1_distance', 0)
        },
        'slot2': {
            'occupied': parsed_telemetry.get('slot2_occupied') == 'true' or parsed_telemetry.get('slot2_occupied') == True,
            'distance': parsed_telemetry.get('slot2_distance', 0)
        }
    }

    return jsonify(state)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=FLASK_PORT, debug=DEBUG_MODE)

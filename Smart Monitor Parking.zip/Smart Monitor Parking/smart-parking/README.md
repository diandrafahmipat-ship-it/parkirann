# Smart Parking Monitoring System - Web Interface

This web application provides a real-time monitoring dashboard and booking control for your IoT Smart Parking system.

## Project Structure
```
smart-parking/
├── app.py              # Main Flask application
├── config.py           # Configuration (ThingsBoard creds)
├── tb_client.py        # ThingsBoard API wrapper
├── templates/
│   └── index.html      # Main dashboard HTML
└── static/
    ├── style.css       # Premium styling
    └── script.js       # Frontend logic
```

## Setup Instructions

### 1. Install Dependencies
Make sure you have Python installed. Open your terminal in the project directory (`smart-parking`) and run:
```bash
pip install flask requests
```

### 2. Configure ThingsBoard
Open `config.py` in a text editor. You **MUST** update the following values with your specific ThingsBoard details:
*   `TB_SERVER_URL`: Your ThingsBoard IP address (e.g., `http://192.168.1.50:8080`).
*   `TB_USERNAME`: Your login username.
*   `TB_PASSWORD`: Your login password.
*   `TB_DEVICE_ID`: The ID of your ESP32 device from ThingsBoard.

### 3. Run the Server
Run the Flask application:
```bash
python app.py
```
It will start locally at `http://localhost:5000` (or `http://0.0.0.0:5000` accessible from other devices on the same network).

### 4. Usage
*   Open your web browser and go to `http://localhost:5000`.
*   You should see the status of Slot 1 and Slot 2 updating in real-time.
*   Click "Book Slot" to reserve a parking spot (turns Blue).
*   The ESP32 should reflect these changes via the LED status.

## Troubleshooting
*   **Data not updating?** Check the console (F12) for errors and ensure `config.py` is correct.
*   **Login Failed?** Check your ThingsBoard username/password in `config.py`.

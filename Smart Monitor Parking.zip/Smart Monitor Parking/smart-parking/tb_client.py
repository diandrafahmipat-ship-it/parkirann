import requests
import json
import time
from config import TB_SERVER_URL, TB_USERNAME, TB_PASSWORD, TB_DEVICE_ID

class ThingsBoardClient:
    def __init__(self):
        self.token = None
        self.base_url = TB_SERVER_URL
        self.device_id = TB_DEVICE_ID

    def login(self):
        """Authenticates with ThingsBoard and retrieves the JWT token."""
        url = f"{self.base_url}/api/auth/login"
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        payload = {"username": TB_USERNAME, "password": TB_PASSWORD}
        
        try:
            response = requests.post(url, headers=headers, json=payload)
            if response.status_code == 200:
                self.token = response.json().get('token')
                return True
            else:
                print(f"Login failed: {response.text}")
                return False
        except Exception as e:
            print(f"Error connecting to ThingsBoard: {e}")
            return False

    def get_headers(self):
        if not self.token:
            self.login()
        return {
            'Content-Type': 'application/json',
            'X-Authorization': f'Bearer {self.token}'
        }

    def get_latest_telemetry(self):
        """Fetches the latest telemetry data for the device."""
        # Note: keys are comma-separated. The User provided keys:
        # slot1_distance, slot2_distance, slot1_occupied, slot2_occupied, slot1_booked, slot2_booked
        # Wait, 'slot1_booked' and 'slot2_booked' are likely sent as telemetry in the ESP32 code provided,
        # but the user also mentioned shared attributes. The ESP32 code publishes them to telemetry.
        # However, to CONTROL them, we should probably use Shared Attributes or Attributes.
        # In the provided ESP32 code: client.subscribe("v1/devices/me/attributes");
        # It listens for attributes.
        # But in the loop, it publishes booked status to telemetry.
        # To make it controllable from Web -> TB -> ESP, we must use SHARED ATTRIBUTES for 'booked' status.
        # The ESP32 will receive attribute updates.
        
        keys = "slot1_distance,slot2_distance,slot1_occupied,slot2_occupied,slot1_booked,slot2_booked"
        url = f"{self.base_url}/api/plugins/telemetry/DEVICE/{self.device_id}/values/timeseries?keys={keys}&useStrictDataTypes=true"
        
        try:
            response = requests.get(url, headers=self.get_headers())
            if response.status_code == 401: # Token expired
                self.login()
                response = requests.get(url, headers=self.get_headers())
            
            if response.status_code == 200:
                return response.json()
            return {}
        except Exception as e:
            print(f"Error fetching telemetry: {e}")
            return {}

    def get_shared_attributes(self):
        """Fetches shared attributes (booked status likely stored here for persistence)."""
        # If we rely on shared attributes for booking, we should fetch them.
        url = f"{self.base_url}/api/plugins/telemetry/DEVICE/{self.device_id}/values/attributes?scope=SHARED_SCOPE"
        
        try:
            response = requests.get(url, headers=self.get_headers())
            if response.status_code == 401:
                self.login()
                response = requests.get(url, headers=self.get_headers())
                
            if response.status_code == 200:
                return response.json()
            return {}
        except Exception as e:
            print(f"Error fetching attributes: {e}")
            return {}

    def save_limit_attribute(self, key, value):
        """Saves a shared attribute to control the device."""
        url = f"{self.base_url}/api/plugins/telemetry/DEVICE/{self.device_id}/SHARED_SCOPE"
        payload = {key: value}
        
        try:
            response = requests.post(url, headers=self.get_headers(), json=payload)
            if response.status_code == 401:
                self.login()
                response = requests.post(url, headers=self.get_headers(), json=payload)
                
            return response.status_code == 200
        except Exception as e:
             print(f"Error saving attribute: {e}")
             return False

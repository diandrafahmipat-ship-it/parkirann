# Configuration for the Smart Parking System

# ThingsBoard Server Configuration
TB_SERVER_URL = "http://192.168.43.250:8080" 

# User Credentials
TB_USERNAME = "tenant@thingsboard.org"
TB_PASSWORD = "tenant" # Default password for 'tenant@thingsboard.org'. Change if your password is different.

# Device ID
TB_DEVICE_ID = "969bb590-d4ed-11f0-acd7-3507a832cf4c"

# Local Server Config
FLASK_PORT = 5000
DEBUG_MODE = True

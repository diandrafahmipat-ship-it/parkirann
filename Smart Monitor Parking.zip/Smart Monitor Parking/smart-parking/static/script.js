async function fetchStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();

        // Update both slots
        updateSlot('slot1', data.slot1);
        updateSlot('slot2', data.slot2);
    } catch (error) {
        console.error('Error fetching status:', error);
    }
}

function updateSlot(slotId, slotData) {
    const card = document.getElementById(`${slotId}-card`);
    const statusBadge = document.getElementById(`${slotId}-status`);
    const icon = document.getElementById(`${slotId}-icon`);
    const distanceEl = document.getElementById(`${slotId}-distance`);

    // Reset classes
    card.classList.remove('status-free', 'status-occupied');

    // Update Distance
    if (slotData.distance !== undefined) {
        distanceEl.textContent = `${parseFloat(slotData.distance).toFixed(1)} cm`;
    }

    if (slotData.occupied) {
        // Red - Occupied
        card.classList.add('status-occupied');
        statusBadge.textContent = 'Occupied';
        icon.className = 'fas fa-car-side';
    } else {
        // Green - Free
        card.classList.add('status-free');
        statusBadge.textContent = 'Available';
        icon.className = 'fas fa-parking';
    }
}

// Poll every 2 seconds to check ThingsBoard data
setInterval(fetchStatus, 2000);

// Initial load
fetchStatus();
